import MainPage from "./Components/MainPage/MainPage.js";
import UnderConstruction from "./UnderConstruction/UnderConstruction.js";
import RutasMasCortas  from './Components/RutasMasCortas/RutasMasCortas.js'
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";

const App =() => {
  return (
    <div className="App">
       <Router>
          <Switch>
              <Route exact path="/" component={MainPage}/>
              <Route exact path="/NotImplemented" component={UnderConstruction}/>
              <Route exact path="/RutasMasCortas" component={RutasMasCortas}/>

          </Switch>
        </Router>

    </div>
  );
}

export default App;

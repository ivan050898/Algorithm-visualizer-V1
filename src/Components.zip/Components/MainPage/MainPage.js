import './MainPage.css'
import {Fragment} from 'react'
import { useHistory } from "react-router-dom";

 const MainPage = () => {
    const history = useHistory();

    const Redirect = () =>{
      history.push('/NotImplemented');
    }
    const RutasMasCortas = () =>{
      history.push('/RutasMasCortas');
    }


    return (
        <Fragment>
            <div class="container">
              <img src={`${process.env.PUBLIC_URL}/logo.png` } style={{paddingLeft:"500px",paddingBottom:"100px"}} ></img>
              <div class="row">
                <button className="btn btn-lg CircularButton1" onClick={RutasMasCortas}> 
                <i class="fas fa-route fa-3x"></i>
                Rutas más cortas</button>
                <button className="btn btn-lg CircularButton2" ><i class="fas fa-hiking fa-3x"></i>Problema de la Mochila</button>
                <button className="btn btn-lg CircularButton3" onClick={Redirect}><i class="fas fa-sync-alt fa-3x"></i>Reemplazo de Equipos</button>
               
               </div>
               <div class="row">       
                 <button className="btn btn-lg CircularButton4" onClick={Redirect}><i class="fas fa-network-wired fa-3x"></i>Árboles Binarios de Búsqueda Óptimos </button>

                <button className="btn btn-lg CircularButton5" onClick={Redirect}><i class="fas fa-football-ball fa-3x"></i>Series deportivas</button>

                <button className="btn btn-lg CircularButton6" onClick={Redirect}><i class="fas fa-calculator fa-3x"></i>Multiplicación de Matrices</button>        
               </div>
            </div>
         


        </Fragment>
    )
}

export default MainPage;

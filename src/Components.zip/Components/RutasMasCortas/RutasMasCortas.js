import './RutasMasCortas.css'
import {Fragment} from 'react'
import SideBar from '../SideBar/SideBar.js'
import { useState} from 'react'
import {unstable_batchedUpdates} from 'react-dom';
import { v4 as uuidv4 } from 'uuid';

const RutasMascortas = () => {
    const NodosDefault =['A','B','C','D','E','F','G','H','I','J']
    const [RutaOptima, setRutaOptima] = useState(false)
    const [cantidadNodos, setcantidadNodos] = useState(1)
    const [MatrizInputs, setMatrizInputs] = useState([['0']])
    const [NodosActuales, setNodosActuales] = useState(['A'])
    const [MatrixIndex, setMatrixIndex] = useState(0)
    const [MatricesD, setMatricesD] = useState([])
    const [MatricesP, setMatricesP] = useState([])

   

    const GenerarD0 = (modo) =>{
      let largo=modo?cantidadNodos+1:cantidadNodos-1
      let newMatriz = new Array(largo).fill(0).map(() => new Array(largo).fill(0));
      for (let i = 0; i <largo; i++) {
        for (let j = 0; j < largo; j++) {
            if( i==j){
              newMatriz[i][j]="0"
            }else{
              newMatriz[i][j]="∞"
            }
        }
      }

      setMatrizInputs(newMatriz)

    }

    const CrearMatriz = () =>{
      let newMatriz = new Array(cantidadNodos).fill(0).map(() => new Array(cantidadNodos).fill(0))
      return newMatriz
    }

    
    const copyMatrix= (Matriz1,Matriz2) =>{
     
      for(let i = 0; i < cantidadNodos; i++){
          for(let j = 0; j < cantidadNodos; j++){
            Matriz1[i][j] = Matriz2[i][j];
          } 
      }
      return Matriz1;
  }

    const AumentarCantidadNodos = () =>{
      if(cantidadNodos<10) {
        unstable_batchedUpdates(() => {
          setcantidadNodos(cantidadNodos+1)
          let ArrayNuevo=NodosActuales
          ArrayNuevo.push(NodosDefault[cantidadNodos])
          setNodosActuales(ArrayNuevo)
          GenerarD0(true)

      })}
    }

    const DecremetarCantidadNodos = () =>{
        if(cantidadNodos>1) {
          unstable_batchedUpdates(() => {
            setcantidadNodos(cantidadNodos-1)
            let ArrayNuevo=NodosActuales
            ArrayNuevo.pop()
            setNodosActuales(ArrayNuevo)
            GenerarD0(false)

          })   
        }
        
    }

   const CambiarNombreNodo = (valor,index) =>{
      let ArrayNuevo=NodosActuales
      ArrayNuevo[index]=valor
      setNodosActuales([...ArrayNuevo])
   }

   const ActualizarMatriz = (valor,i,j) =>{
      let MatrizNueva=MatrizInputs
      MatrizInputs[i][j]=valor
      setMatrizInputs(MatrizNueva)
   }


   const TransformarMatriz= (Matriz) =>{
     
    for(let i = 0; i < cantidadNodos; i++){
        for(let j = 0; j < cantidadNodos; j++){
          if(Matriz[i][j]=="∞"){
            Matriz[i][j]=Number.MAX_SAFE_INTEGER
          }else{
            Matriz[i][j]=parseInt(Matriz[i][j])
          }
        } 
    }
    return Matriz;
  }

   const Floyd = () =>{
    let newMatriz=CrearMatriz()
    let matrizResultado=MatrizInputs
    copyMatrix(newMatriz,MatrizInputs)
    TransformarMatriz(newMatriz)
    for(let k = MatrixIndex; k < cantidadNodos; k++){
      for(let i = 0; i < cantidadNodos; i++){
          for(let j = 0; j < cantidadNodos; j++){
              if(newMatriz[i][k] + newMatriz[k][j] < newMatriz[i][j]){
                  newMatriz[i][j] = newMatriz[i][k]+ newMatriz[k][j]
                  matrizResultado[i][j] = (newMatriz[i][k]+ newMatriz[k][j]).toString()

                 // PMatrixCopy[i][j] = k+1;
              }
          }
      }
      console.log(matrizResultado)
      setMatrizInputs([...matrizResultado])
      setMatrixIndex(MatrixIndex+1)
     
      break
      
     // this.DArrays.push(this.copyMatrix(this.infinite, DMatrix));
     // this.PArrays.push(this.copyMatrix(0, PMatrixCopy));
    }
}




    return (
      <Fragment>
          <div  style={{paddingLeft:"100px",paddingTop:"10px"}}>
            <button className="btn" style={{backgroundColor:"teal",color:"white",marginRight:"20px"}} onClick={()=> Floyd()} >Ejecutar</button>
            <button className="btn" style={{backgroundColor:"teal",color:"white",marginRight:"20px"}} >Anterior</button>
            <button className="btn" style={{backgroundColor:"teal",color:"white",marginRight:"20px"}} >Siguiente</button>
            <button className="btn" style={{backgroundColor:"teal",color:"white",marginRight:"20px"}} >Matriz P</button>
            <button className="btn" style={{backgroundColor:"teal",color:"white",marginRight:"20px"}} >Cargar Archivo</button>
            <button className="btn" style={{backgroundColor:"teal",color:"white",marginRight:"20px"}} >Guardar Archivo</button>

          </div>
          <div  style={{paddingLeft:"10px",paddingTop:"50px"}}>
                <div className="row" >
                      <div className="col-sm-3 card">
                        <div className="number" style={{marginBottom:"30px"}} >
                          <h6 style={{padding:"0",margin:"0",display:"inline-block"}}>Cantidad de nodos:  </h6>
                          <button className="btn btn-dark"  onClick={()=> DecremetarCantidadNodos()} style={{marginLeft:"10px"}} >-</button>
                          <input type="text" value={cantidadNodos} style={{width:"55px",height:"35px"}}/>
                          <button className="btn btn-dark" onClick={()=> AumentarCantidadNodos()} >+</button>
                        </div>
                       {!RutaOptima && <div>
                    {NodosActuales.map((item,i) => {
                        return (
                          <div  style={{display:"inline-block",marginBottom:"10px"}}>
                              <p  style={{display:"inline-block",marginRight:"10px"}} >Nodo <strong>#{i} &#x2192; </strong></p>
                              <p  style={{display:"inline-block",marginRight:"10px"}}>Nombre:</p>
                              <input defaultValue ={NodosActuales[i]}  onChange={e => CambiarNombreNodo(e.target.value,i)} style={{padding:"0",margin:"0",display:"inline-block",width:"100px"}}></input>
                          </div>

                        )
                  
                    })}
                        </div>}
                      </div>
                      <div className="col-sm-8 card">
                        <div class="table-responsive" style={{width:"90%"}}>

                        <table class="table table-bordered table-sm ">
                            <thead>
                              <tr>
                                <th scope="col" style={{width:"50px",height:"30px"}}>D ({MatrixIndex})</th>
                                {NodosActuales.map((item,i) => {
                                  return (
                                    <th scope="col" style={{width:"50px",height:"30px"}}>{item}</th>

                                  ) })}
                              </tr>
                            </thead>
                            <tbody>
                            {NodosActuales.map((item,i) => {
                                  return (
                                    <tr>
                                      <th scope="row">{item}</th>
                                      {NodosActuales.map((item,j) => {
                                      return (
                                      <td style={{width:"50px",height:"30px"}}><div key={uuidv4()}>
                                        <input type="text" onChange={e =>ActualizarMatriz(e.target.value,i,j)}  defaultValue={MatrizInputs[i][j].toString()} style={{width:"50px",height:"30px"}}>
                                          </input> </div></td>
                                      ) })}
                                    </tr>

                                  ) })}
                              
                            </tbody>
                          </table>
                      </div>
               
                  </div>
                </div>

         </div>
         <SideBar></SideBar>

      </Fragment>
  )
}

export default RutasMascortas
